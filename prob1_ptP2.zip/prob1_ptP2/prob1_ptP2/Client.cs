﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

/* 
 TEXT PROBLEMA
Să se implementeze o aplicație C# pentru evidența comenzilor clienților. Un client poate plasa mai multe comenzi. Baza de date a aplicației (SQL Server local db) conține două tabele relaționate: Clienti: Clientild, Nume şi prenume, CNP, TipClient
Comenzi: Comandald, ClientId (cheie externă, relaționare cu câmpul ClientId din tabelul Clienti), Denumire produs, Cantitate, Pret, Data comanda
Validarea CNP-ului (1p)
Crearea bazei de date (1p)
Se va ține cont de relaționarea dintre tabele (vor fi afişate numai comenzile unui anumit client) (2p)
Se va folosi controale de tip textbox si combobox pentru adaugarea de informatii in baza de date. (2p)
Se va cauta un client si se va afisa toate comenzile sale (1p)
Se va crea un fisier "Statistici.txt" unde se va salva datele clientului selectat si se va calcula şi afişa valoarea
totală a tuturor comenzilor pentru clientul respectiv (suma produselor dintre Cantitate si Pret pentru fiecare comandă) (2p)
Se acordă din oficiu 1 punct.
 */

namespace prob1_ptP2
{

    public static class DatabaseConn
    {
        public static string ConnectionString =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\RESTAURANT\Clienti1.mdf;Integrated Security=True;Connect Timeout=30";
    }

    public partial class Client : Form
    {


        SqlConnection conn = new SqlConnection(DatabaseConn.ConnectionString);

        public Client()
        {
            InitializeComponent();
            IncarcaClienti();
        }

        private void Client_Load(object sender, EventArgs e)
        {

        }

        void IncarcaClienti()
        {
            comboBox2.Items.Clear();
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT ClientId, NumePrenume FROM Clienti", conn);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                comboBox2.Items.Add(new ComboBoxItem(rd["NumePrenume"].ToString(), rd["ClientId"].ToString()));
            }
            conn.Close();
        }

        private bool EsteCNPValid(string cnp)
        {
            return cnp.Length == 13 && cnp.All(char.IsDigit);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!EsteCNPValid(textBox2.Text))
            {
                MessageBox.Show("CNP invalid!");
                return;
            }

            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Clienti (NumePrenume, CNP, TipClient) VALUES (@nume, @cnp, @tip)", conn);
            cmd.Parameters.AddWithValue("@nume", textBox1.Text);
            cmd.Parameters.AddWithValue("@cnp", textBox2.Text);
            cmd.Parameters.AddWithValue("@tip", comboBox1.Text);
            cmd.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("Client adăugat.");
            IncarcaClienti();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Selectează un client!");
                return;
            }

            var clientId = ((ComboBoxItem)comboBox2.SelectedItem).Value;

            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Comenzi (ClientId, DenumireProdus, Cantitate, Pret, DataComanda) VALUES (@id, @prod, @cant, @pret, @data)", conn);
            cmd.Parameters.AddWithValue("@id", clientId);
            cmd.Parameters.AddWithValue("@prod", textBox3.Text);
            cmd.Parameters.AddWithValue("@cant", int.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@pret", decimal.Parse(textBox6.Text));
            cmd.Parameters.AddWithValue("@data", dateTimePicker1.Value);
            cmd.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("Comandă adăugată.");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT ClientId FROM Clienti WHERE NumePrenume LIKE @nume", conn);
            cmd.Parameters.AddWithValue("@nume", "%" + textBox5.Text + "%");
            object result = cmd.ExecuteScalar();
            conn.Close();

            if (result != null)
            {
                AfiseazaComenziClient((int)result);
            }
            else
            {
                MessageBox.Show("Clientul nu a fost găsit.");
            }
        }

        private void AfiseazaComenziClient(int clientId)
        {
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT DenumireProdus, Cantitate, Pret, DataComanda FROM Comenzi WHERE ClientId = @id", conn);
            da.SelectCommand.Parameters.AddWithValue("@id", clientId);
            da.Fill(dt);
            conn.Close();

            dataGridView1.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Selectează un client!");
                return;
            }

            string nume = ((ComboBoxItem)comboBox2.SelectedItem).Text;
            int clientId = int.Parse(((ComboBoxItem)comboBox2.SelectedItem).Value);

            AfiseazaComenziClient(clientId); // Încărcăm comenzile în DataGridView

            decimal total = 0;
            using (StreamWriter sw = new StreamWriter("Statistici.txt"))
            {
                sw.WriteLine($"Client: {nume}");
                sw.WriteLine("Comenzi:");
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.IsNewRow) continue;

                    string prod = row.Cells["DenumireProdus"].Value.ToString();
                    int cant = Convert.ToInt32(row.Cells["Cantitate"].Value);
                    decimal pret = Convert.ToDecimal(row.Cells["Pret"].Value);
                    decimal suma = cant * pret;
                    total += suma;

                    sw.WriteLine($"{prod} x {cant} = {suma} lei");
                }
                sw.WriteLine($"Total: {total} lei");
            }

            MessageBox.Show("Statistici generate în fișierul Statistici.txt");
        }

        public class ComboBoxItem
        {
            public string Text { get; set; }
            public string Value { get; set; }
            public ComboBoxItem(string t, string v) { Text = t; Value = v; }
            public override string ToString() => Text;
        }
    }
    
}
