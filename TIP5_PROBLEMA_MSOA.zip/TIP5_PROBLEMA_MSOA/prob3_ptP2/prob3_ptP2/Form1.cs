﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prob3_ptP2
{
    public partial class Form1 : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\MAGAZIN\magazin.mdf;Integrated Security=True;Connect Timeout=30");

        public Form1()
        {
            InitializeComponent();
            IncarcaAngajati();
        }

        private bool ValidareCNP(string cnp)
        {
            return cnp.Length == 13 && cnp.All(char.IsDigit);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void IncarcaAngajati()
        {
            comboBox1.Items.Clear();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Angajati", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(new ComboBoxItem(dr["NumePrenume"].ToString(), (int)dr["AngajatId"]));
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e) //adauga angajat
        {
            if (!ValidareCNP(textBox2.Text))
            {
                errorProvider1.SetError(textBox2, "CNP invalid");
                return;
            }
            errorProvider1.SetError(textBox2, "");

            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Angajati (NumePrenume, CNP, Functie) VALUES (@n, @c, @f)", con);
            cmd.Parameters.AddWithValue("@n", textBox1.Text);
            cmd.Parameters.AddWithValue("@c", textBox2.Text);
            cmd.Parameters.AddWithValue("@f", textBox3.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Angajat adăugat!");
            IncarcaAngajati();
        }

        private void button2_Click(object sender, EventArgs e) //adauga proiect
        {
            if (comboBox1.SelectedItem == null) return;

            var angajat = (ComboBoxItem)comboBox1.SelectedItem;

            SqlCommand cmd = new SqlCommand("INSERT INTO Proiecte (AngajatId, Functie_pe_proiect, Nr_ore_alocate, Plata_ora) " +
                                            "VALUES (@id, @fct, @ore, @plata)", con);
            cmd.Parameters.AddWithValue("@id", angajat.Value);
            cmd.Parameters.AddWithValue("@fct", textBox4.Text);
            cmd.Parameters.AddWithValue("@ore", int.Parse(textBox5.Text));
            cmd.Parameters.AddWithValue("@plata", float.Parse(textBox6.Text));

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Proiect adaugat!");
        }

        private void button3_Click(object sender, EventArgs e) //cauta
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Angajati WHERE NumePrenume LIKE @nume", con);
            cmd.Parameters.AddWithValue("@nume", "%" + textBox7.Text + "%");
            SqlDataReader dr = cmd.ExecuteReader();

            int id = -1;
            if (dr.Read())
            {
                id = (int)dr["AngajatId"];
            }
            else
            {
                MessageBox.Show("Angajatul nu a fost gasit.");
            }

            dr.Close(); // Închide DataReader înainte să folosești din nou conexiunea
            con.Close();

            if (id != -1)
            {
                AfiseazaProiecte(id);
            }
        }

        private void AfiseazaProiecte(int id)
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Proiecte WHERE AngajatId = @id", con);
            da.SelectCommand.Parameters.AddWithValue("@id", id);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e) //buton statistici
        {
            if (comboBox1.SelectedItem == null) return;
            var angajat = (ComboBoxItem)comboBox1.SelectedItem;
            double total = 0;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Proiecte WHERE AngajatId = @id", con);
            cmd.Parameters.AddWithValue("@id", angajat.Value);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            using (StreamWriter sw = new StreamWriter("Statistici1.txt"))
            {
                sw.WriteLine($"Statistici pentru angajatul: {angajat.Text}\n");
                while (dr.Read())
                {
                    MessageBox.Show("Proiect gasit"); // vezi dacă intră în buclă

                    int ore = Convert.ToInt32(dr["Nr_ore_alocate"]);
                    double plata = Convert.ToDouble(dr["Plata_ora"]);
                    double salariu = ore * plata;
                    total += salariu;

                    sw.WriteLine($"Functie pe proiect: {dr["Functie_pe_proiect"]}, Ore: {ore}, Plata/ora: {plata}, Total: {salariu}");
                }
                sw.WriteLine($"\nSalariu Total: {total} lei");
            }
            dr.Close();
            con.Close();
            MessageBox.Show("Fisierul Statistici1.txt a fost salvat.");
        }
    }
}
